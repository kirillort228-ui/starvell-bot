import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import httpx

from starvell_client import StarvellClient, StarvellApiError
from database import Database
import chat_watcher as watcher

USER = {"id": 1, "username": "seller"}
UUID = "12345678-1234-1234-1234-123456789abc"


class ApiTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.client = StarvellClient("session=test")
        self.calls = []

    async def asyncTearDown(self):
        await self.client.close()

    async def transport(self, handler):
        await self.client.client.aclose()
        async def record(request):
            import json
            payload = json.loads(request.content) if request.content else None
            self.calls.append((request.method, request.url.path, payload))
            self.assertTrue(request.url.path.startswith("/api/"))
            return handler(request, payload)
        self.client.client = httpx.AsyncClient(transport=httpx.MockTransport(record))

    async def test_chats_use_api_and_flatten_current_profile(self):
        def reply(request, payload):
            if request.url.path == "/api/profiles/me":
                return httpx.Response(200, json={"success": True, "data": {
                    "user": USER, "unreadChatIds": ["c"], "balance": {"available": 42},
                    "orderCountsByType": {"salesOrdersCount": 2},
                }})
            return httpx.Response(200, json={"success": True, "data": [{"id": "c"}]})
        await self.transport(reply)
        data = await self.client.get_chats()
        self.assertEqual(data["pageProps"]["user"]["unreadChatIds"], ["c"])
        self.assertEqual(data["pageProps"]["user"]["ordersCount"]["salesOrdersCount"], 2)
        self.assertEqual(data["pageProps"]["chats"], [{"id": "c"}])
        self.assertEqual(len(self.calls), 2)

    async def test_expired_session(self):
        await self.transport(lambda r, p: httpx.Response(403, json={
            "success": False, "data": {"code": "SESSION_NOT_FOUND"},
        }))
        with self.assertRaisesRegex(StarvellApiError, "Сессия"):
            await self.client.get_chats()

    async def test_html_not_success(self):
        await self.transport(lambda r, p: httpx.Response(200, text="<html>login</html>"))
        with self.assertRaisesRegex(StarvellApiError, "без JSON"):
            await self.client.get_chats()

    async def test_success_false_not_empty_list(self):
        await self.transport(lambda r, p: httpx.Response(200, json={"success": False, "message": "denied"}))
        with self.assertRaisesRegex(StarvellApiError, "denied"):
            await self.client._api("POST", "/chats/list")

    async def test_orders_paginate_with_seller_filter(self):
        def reply(request, payload):
            if request.url.path == "/api/profiles/me":
                return httpx.Response(200, json={"data": {"user": USER}})
            self.assertEqual(payload["filter"], {"userType": "seller"})
            self.assertEqual(payload["with"], {"buyer": True})
            start = payload["offset"]
            items = [{"id": i} for i in range(start, min(start + 50, 51))]
            return httpx.Response(200, json={"data": {"items": items, "totalCount": 51}})
        await self.transport(reply)
        data = await self.client.get_orders()
        self.assertEqual(len(data["pageProps"]["orders"]), 51)
        self.assertEqual([p[2]["offset"] for p in self.calls[1:]], [0, 50])

    async def test_repeated_page_fails(self):
        await self.transport(lambda r, p: httpx.Response(200, json={"data": [{"id": "same"}]}))
        with self.assertRaisesRegex(StarvellApiError, "повторил"):
            await self.client._list_all("/chats/list", page_size=1)

    async def test_unknown_list_format_fails(self):
        await self.transport(lambda r, p: httpx.Response(200, json={"data": {"error": "unknown"}}))
        with self.assertRaisesRegex(StarvellApiError, "формат"):
            await self.client._list_all("/chats/list")

    async def test_catalog_categories_and_pagination(self):
        def reply(request, payload):
            page = payload["offset"]
            return httpx.Response(200, json={"data": {"hasMore": page == 0, "categories": [{
                "id": page + 3, "name": "Accounts", "game": {"id": 1, "name": "Roblox"},
                "offers": [{"publicId": UUID if page == 0 else "another", "availability": 1,
                            "descriptions": {"rus": {"briefDescription": "My offer"}}}],
            }]}})
        await self.transport(reply)
        offers = await self.client.collect_profile_page_offers("seller")
        self.assertEqual(len(offers), 2)
        self.assertEqual(offers[0]["gameId"], 1)
        self.assertEqual(offers[0]["categoryId"], 3)
        self.assertEqual([c[2]["offset"] for c in self.calls], [0, 10])

    async def test_foreign_account_offers_rejected(self):
        self.client._user = USER
        with self.assertRaisesRegex(StarvellApiError, "только товары"):
            await self.client.collect_active_seller_offers("other")

    async def test_history_fetches_before_id_in_order(self):
        def reply(request, payload):
            if "beforeId" not in payload:
                result = {"items": [{"id": "3"}, {"id": "2"}], "hasMoreBefore": True, "nextCursor": "2"}
            else:
                self.assertEqual(payload["beforeId"], "2")
                result = {"items": [{"id": "1"}, {"id": "old"}], "hasMoreBefore": False}
            return httpx.Response(200, json={"data": result})
        await self.transport(reply)
        messages = await self.client.get_messages_since("chat", "old")
        self.assertEqual([m["id"] for m in messages], ["1", "2", "3"])

    async def test_missing_history_checkpoint_does_not_replay_old_messages(self):
        await self.transport(lambda r, p: httpx.Response(200, json={"data": {
            "items": [{"id": "old-message"}], "hasMoreBefore": False,
        }}))
        with self.assertRaisesRegex(StarvellApiError, "точку отсчёта"):
            await self.client.get_messages_since("chat", "deleted-checkpoint")

    async def test_empty_bump_success_and_no_automatic_retries(self):
        await self.transport(lambda r, p: httpx.Response(204))
        self.assertEqual(await self.client.bump_offers(1, [3, 3]), {"ok": True})
        self.assertEqual(self.calls[0][2], {"gameId": 1, "categoryIds": [3]})
        self.assertEqual(len(self.calls), 1)

    async def test_offer_update_uses_api_prefix(self):
        await self.transport(lambda r, p: httpx.Response(200, json={"data": {"ok": True}}))
        await self.client.update_offer_by_public_id(UUID, {"isActive": True})
        self.assertEqual(self.calls[0][1], f"/api/offers/{UUID}/update")


class IntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = Database(str(Path(self.temp.name) / "test.db"))
        await self.db.init()
        account_id = await self.db.add_account(5, "session=test", "seller", None)
        self.account = await self.db.get_account(account_id)

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def test_watcher_retries_failure_without_advancing_and_uses_plain_text(self):
        await self.db.save_last_message_id(self.account.id, "c", "old")
        message = {"id": "new", "authorId": 2, "type": "DEFAULT", "content": "<broken>"}
        client = SimpleNamespace(
            close=AsyncMock(),
            get_chats=AsyncMock(return_value={"pageProps": {"user": USER, "chats": [{
                "id": "c", "lastMessage": message, "unreadMessageCount": 1,
                "participants": [USER, {"id": 2, "username": "buyer"}],
            }]}}),
            get_messages_since=AsyncMock(return_value=[message]),
        )
        telegram = SimpleNamespace(send_message=AsyncMock(side_effect=watcher.TelegramBadRequest(
            method=SimpleNamespace(), message="failed",
        )))
        with patch.object(watcher, "StarvellClient", return_value=client):
            await watcher.check_one_account(telegram, self.db, self.account)
            self.assertEqual(await self.db.get_last_message_id(self.account.id, "c"), "old")
            telegram.send_message.side_effect = None
            await watcher.check_one_account(telegram, self.db, self.account)
        self.assertEqual(await self.db.get_last_message_id(self.account.id, "c"), "new")
        self.assertIsNone(telegram.send_message.call_args.kwargs["parse_mode"])
        self.assertIn("<broken>", telegram.send_message.call_args.args[1])

    async def test_customer_text_cannot_trigger_paid_event(self):
        self.assertFalse(watcher.is_purchase_paid_event({"type": "DEFAULT", "content": "ORDER_PAID"}))
        self.assertTrue(watcher.is_purchase_paid_event({"type": "NOTIFICATION", "metadata": {"notificationType": "ORDER_PAID"}}))

    async def test_chat_reminder_settings_reach_sender(self):
        os.environ.setdefault("BOT_TOKEN", "123456789:" + "A" * 35)
        import bot as app
        from datetime import datetime, timedelta, timezone
        await self.db.set_account_setting(5, "confirm_reminder_enabled", "1")
        await self.db.set_account_setting(5, "confirm_reminder_chat_text:c", "Hello {username}")
        order = {"id": "order", "chatId": "c", "sellerId": 1, "status": "PAID",
                 "buyer": {"id": 2, "username": "buyer"},
                 "createdAt": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()}
        client = SimpleNamespace(close=AsyncMock(), send_chat_message=AsyncMock(), get_orders=AsyncMock(
            return_value={"pageProps": {"user": USER, "orders": [order]}}))
        with patch.object(app, "db", self.db), patch.object(app, "StarvellClient", return_value=client), patch.object(app, "should_run_confirm_reminder_now", return_value=True), patch.object(app.asyncio, "sleep", new=AsyncMock()):
            await app.process_confirm_reminders_for_account(self.account)
            await app.process_confirm_reminders_for_account(self.account)
        client.send_chat_message.assert_awaited_once_with("c", "Hello buyer")
        await app.bot.session.close()

    async def test_product_buttons_fit_telegram_callback_limit(self):
        os.environ.setdefault("BOT_TOKEN", "123456789:" + "A" * 35)
        import bot as app
        keyboard = app.build_message_products_keyboard(
            [{"publicId": UUID}], action_prefix="msg_product:autodelivery",
        )
        for row in keyboard.inline_keyboard:
            for button in row:
                self.assertLessEqual(len(button.callback_data.encode()), 64)
        self.assertEqual(keyboard.inline_keyboard[0][0].callback_data, "msg_product:autodelivery:select:0")
        await app.bot.session.close()

    async def test_order_id_falls_back_to_notification_metadata(self):
        self.assertEqual(watcher.get_order_id_from_message({"metadata": {"orderId": "order"}}), "order")

    async def test_save_selected_products_and_chat_product_fallback(self):
        os.environ.setdefault("BOT_TOKEN", "123456789:" + "A" * 35)
        import bot as app
        offers = [{"offerPublicId": UUID, "gameId": 1, "categoryId": 3}]
        with patch.object(app, "db", self.db):
            await app.save_auto_raise_selected_products(5, offers)
            self.assertEqual((await app.get_auto_raise_selected_products(5))[0]["offerPublicId"], UUID)
        self.assertIsInstance(app.extract_products_from_chats_data({"pageProps": {"chats": [{"lastMessage": {}}]}}), list)
        await app.bot.session.close()


if __name__ == "__main__":
    unittest.main()
